package com.yash.assign2;

import java.time.LocalDate;

public class EmployeeDetails {
	private int empid;
	private String empname;
	private double empsalary;
	private String empaddress;
	private LocalDate emp_dob;
	private LocalDate emp_doj;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public double getEmpsalary() {
		return empsalary;
	}

	public void setEmpsalary(double empsalary) {
		this.empsalary = empsalary;
	}

	public String getEmpaddress() {
		return empaddress;
	}

	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}

	public LocalDate getEmp_dob() {
		return emp_dob;
	}

	public void setEmp_dob(LocalDate emp_dob) {
		this.emp_dob = emp_dob;
	}

	public LocalDate getEmp_doj() {
		return emp_doj;
	}

	public void setEmp_doj(LocalDate emp_doj) {
		this.emp_doj = emp_doj;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empid=" + empid + ", empname=" + empname + ", empsalary=" + empsalary + ", empaddress="
				+ empaddress + ", emp_dob=" + emp_dob + ", emp_doj=" + emp_doj + "]";
	}

	public static void main(String[] args) {

		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setEmpid(101);
		employeeDetails.setEmpname("Swapnil");
		employeeDetails.setEmpsalary(50000);
		employeeDetails.setEmpaddress("Rajgurunagar");
		employeeDetails.setEmp_dob(LocalDate.of(1995, 11, 23));
		employeeDetails.setEmp_doj(LocalDate.of(2022, 8, 22));

		System.out.println(employeeDetails);

	}

}
